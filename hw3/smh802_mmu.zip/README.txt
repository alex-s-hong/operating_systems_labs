This program will be bulit by using provided makefile.
This will be safe on C++11 or later.
